import java.util.Scanner;
import java.util.Random;
public class NormalGame {
    private static String plural;
    private static int guesses = 3;
    private static boolean isCorrect;
    private static double range=10;
    private static int staticGuesses =3;


    public static void start(){
        int wins=NumberGuesser.getWins();
        guesses=getStaticGuesses();
        isCorrect=false;
        Scanner guessInput = new Scanner(System.in);
        System.out.printf("Welcome to Number Guesser!\nThe computer will pick a number between 1 and %.0f.\nYou will then have to guess the number.\nYou will be given three tries. The game will tell you if your answer is too high or too low.\nThe answer will be a WHOLE number (no decimals)\n", range);
        System.out.print("\033[2J\033[1;1H");
        double randomNumber = ((Math.round(Math.random() * (range -1))+1));
        if(NumberGuesser.getWins()>2){
            System.out.printf("You've won %d games in a row!\n", wins);
        }
        System.out.printf("Computer has picked a number. %.0f\nGuess the number: ",randomNumber);
        guesses--;
        for(int i=0;i<=guesses;guesses--){
            double guess=guessInput.nextDouble();
            System.out.print("\033[2J\033[1;1H");
            if(guesses==1){
                plural="";
            }else{
                plural="es";
            }

            if(guess==randomNumber){
                System.out.print("\033[2J\033[1;1H");
                isCorrect=true;
            }
            else if(guess>randomNumber){
                System.out.print("\033[2J\033[1;1H");
                System.out.printf("%.0f was incorrect.TOO HIGH!\nYou have %d guess%s left. TRY AGAIN: ",guess,guesses, plural);
            }
            else if(guess<randomNumber){
                System.out.print("\033[2J\033[1;1H");
                System.out.printf("%.0f was incorrect.TOO LOW!\nYou have %d guess%s left. TRY AGAIN: ",guess,guesses, plural);
            }
            if(guesses>=0 && isCorrect){
                System.out.print("\033[2J\033[1;1H");
                System.out.println("You got it!");
                System.out.printf("The number was: %.0f\n", randomNumber);
                NumberGuesser.youWin();
                NumberGuesser.postGameScreen();
            }
            if(guesses==0 && !isCorrect){
                System.out.print("\033[2J\033[1;1H");
                System.out.println("You have run out of guesses");
                System.out.printf("The number was: %.0f\n", randomNumber);
                NumberGuesser.youLose();
                NumberGuesser.postGameScreen();
            }
        }
    }


    public static int getGuesses() {
        return guesses;
    }
    public static int getStaticGuesses(){
        return staticGuesses;
    }

    public static void setGuesses(int guesses) {
        NormalGame.guesses = guesses;
        staticGuesses=guesses;
    }
}
