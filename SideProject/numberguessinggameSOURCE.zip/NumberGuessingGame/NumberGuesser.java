/*Jason Buras 11/16/22
 Purpose: for fun
 Description: A number between 1 and (User defined) is picked at random. The user is then prompted to
 pick a number. If the number matches the number picked at random, the player wins.*/
import java.util.Scanner;

public class NumberGuesser{
    private static boolean youWin;
    private static boolean cantRead;
    private static int wins;
    public static void main(String[] args){
        mainMenu();
    }
    public static void mainMenu() {
        System.out.print("\033[2J\033[1;1H");
        Scanner modePicker = new Scanner(System.in);
        System.out.print("MAIN MENU:\n1) Normal Game(WORKS)\n2) Let The Computer Guess!(NOT SETUP YET)\n3) Game Options (UNDER CONSTRUCTION)\nPick a number to select an option: ");
        int gameMode = modePicker.nextInt();
        switch (gameMode) {
            case 1: NormalGame.start(); break;
            case 2: cantRead = true; break;
            case 3: Settings.start(); break;
        }
    }
    public static void postGameScreen(){
        if(youWin){
            wins++;
        }
        else if(!youWin){
            wins=0;
        }
        Scanner playAgainSelect = new Scanner(System.in);
        System.out.print("Would you like to play again?\n1) Yes\n2) No\n3) Main Menu\nSelect Number: ");
        int playAgain = playAgainSelect.nextInt();
        System.out.print("\033[2J\033[1;1H");
        if (playAgain == 1) {
            NormalGame.start();
        }
        else if (playAgain == 2) {
            long startTime = System.currentTimeMillis();
            if (false||(System.currentTimeMillis() - startTime) < 3000) {
                System.out.println("Thanks for playing!");
            }
            System.exit(0);
        }
        else if (playAgain == 3) {
            mainMenu();
        }
    }


    public static void youWin() {
        youWin=true;
    }
    public static void youLose() {
        youWin=false;
        wins=0;
        postGameScreen();
    }

    public static int getWins() {
        return wins;
    }

    public static void setCantRead(boolean cantRead) {
        NumberGuesser.cantRead = cantRead;
    }
}