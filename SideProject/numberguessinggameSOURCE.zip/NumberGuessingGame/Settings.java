import java.util.Scanner;
public class Settings {
    private static int guessSet;
    public static void start(){
        System.out.print("\033[2J\033[1;1H");
        Scanner selection=new Scanner(System.in);
        System.out.print("OPTIONS\n1) Set # of guesses.\n2) [PLACE HOLDER]\n3) [PLACE HOLDER]\nSelect a number: ");
        int select= selection.nextInt();
        if (select == 1) {
            System.out.print("How many guesses would you like? ");
            guessSet = selection.nextInt();
            NormalGame.setGuesses(guessSet);
        } else if (select==2) {
          System.out.println("This is a placeholder");
        } else if (select==3) {
            System.out.println("This is a placeholder too");
        }
        System.out.print("\033[2J\033[1;1H");
        if(NormalGame.getGuesses() >= 10){
            System.out.println("You really need that many guesses...?");
        }
        else if(NormalGame.getGuesses()==1){
            System.out.print("ONE GUESS??\nMaybe you'd like it if I made a Russian Roulette game\n");
        }
        System.out.print("MENU:\n1) Normal Game(WORKS)\n2) Let The Computer Guess!(NOT SETUP YET)\n3) Game Options (UNDER CONSTRUCTION)\nPick a number to select an option: ");
        int gameMode=selection.nextInt();
        if (gameMode == 1) {
            NormalGame.start();
        } else if (gameMode == 2) {
            NumberGuesser.setCantRead(true);
        } else if (gameMode == 3) {
            start();
        }


    }
}
