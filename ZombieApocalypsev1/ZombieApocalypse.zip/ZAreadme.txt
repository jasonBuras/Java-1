                    _     _      
                   | |   (_)     
 _______  _ __ ___ | |__  _  ___ 
|_  / _ \| '_ ` _ \| '_ \| |/ _ \
 / / (_) | | | | | | |_) | |  __/
/___\___/|_| |_| |_|_.__/|_|\___|
                             _                      
                            | |                     
  __ _ _ __   ___   ___ __ _| |_   _ _ __  ___  ___ 
 / _` | '_ \ / _ \ / __/ _` | | | | | '_ \/ __|/ _ \
| (_| | |_) | (_) | (_| (_| | | |_| | |_) \__ \  __/
 \__,_| .__/ \___/ \___\__,_|_|\__, | .__/|___/\___|
      | |                       __/ | |             
      |_|                      |___/|_|    
By: Jason Buras

How to Play:
Put "ZombieApocalypse.class" on your Desktop

	For Windows:
	Press Windows+R
	Type "cd Desktop" and enter
	then "java ZombieApocalypse" and enter
	Follow the instructions.

	For Mac:
	lol idk. open your terminal and follow along the Windows instructions.

	For Linux: 
	You're on Linux. You already know what to do.

To terminate the code (in case you get stuck or something), press Ctrl+C. You will have to type
"java ZombieApocalypse" again to restart the game.

Navigate your way to the objective by using:
w: Move Up
s: Move Down
a: Move Left
d: Move Right

Use Capital Letters in order to move two spaces in the respective direction.

Avoid the Zombies on your way to the objective.

Custom Features:
1.	Added colors using ANSI
2.	I added a start screen where you enter your name, and then pick a game mode.
	a.	After entering your name, you are presented with different options.
	b.	Game Modes:
		i.	Campaign- A preset 3 levels where each level adds a new zombie
		ii.	Survival- See how many levels you can pass before a zombie kills you, or you run out of food.
	c.	Surprise
		i.	Well, it’s a surprise I can’t tell you what it is in here.
	d.	Help
		i.	This is where you can go to understand game concepts if you ignore the readme.
3.	Expanded game board
	a.	On levels 2 and 3, and in survival-mode, you may notice the board expanded to 15x15. That’s because during testing, it was impossible to survive against two zombies on a 10x10 board.
4.	Added food. 
	a.	The player starts with 
5.	Added Sprint feature
	a.	The player can use capital letters (WASD) to move two tiles. Useful for evading zombies
	b.	While sprinting, the player consumes 2 food.
6.	Added two new zombies
	a.	Smart Zombie- Makes moves based on the player’s position. Can move vertically, horizontally, and diagonally. 
	b.	(ZOMBIE3NAME)- Moves randomly, but can move 2 grid positions Vertically and horizontally, but not diagonally. 
7.	Add a key
	a.	You must collect a key before reaching the exit in order to unlock the door
	b.	The key also gives you food.
8.	Added borders so the player couldn’t move off the board.
9.	Added instructions that display during gameplay to help noobs.
10.	QOL feature: Clear the terminal after every move.
11.	Added God Mode
	a.	For testing purposes of course. When asked for your name simply enter “God”
12.	Added Easter Eggs
	a.	Well again… I can’t mention them here.
	b.	The fact that it’s listed after instructions on how to access God mode is your only hint.

	