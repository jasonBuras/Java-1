//Contains all methods/data that manages the game rules
/*The Game class will contain all data/methods for managing the game's rules.
Game class should contain the main algorithm that runs the game, where the
following actions occur: Initially start the game then run the game loop,
The game loop typically performs two tasks:
update game state then render game to display.*/
import java.util.Scanner;
import java.awt.event.KeyEvent;


public class Game{
	private static boolean gameOver=false;
	private static long time;
	private static int seconds;
	private static boolean zombieKill=false;
	private static int noMagicNumbers;

	
	public static void intro(){
		Scene.gameOver(); 		//draw scene
		StdDraw.show(100); 	//show graphics
	}
	public static void main(String[] args){
		start(); 	//Start game
		while (gameOver==false){
				update();	//1. Update Game
				render();	//2. Render Game
		}
		
	    if (gameOver ==true){
			gameOver();	
		}

		if(Exit.isTouching()==true){
			gameWin();
		}

		 

	}
	public static void start(){
			gameOver=false;
			Scanner input = new Scanner(System.in);
			Scene.intro(); //Skipping intro for now
			Scene.start();
			Zombie.start();
			Exit.start();
			Player.start(input);
			time = System.currentTimeMillis();


	}
	public static void render(){
		Scene.draw(); 		//draw scene
		Zombie.draw();
		Player.draw();
		Hud.draw();
		Exit.draw();
		StdDraw.show(100); 	//show graphics
		
	}

	public static void update(){
		//check for input
		Player.update();//update player
		Zombie.update(); //update zombie
		/*if (Exit.isTouching()==true){
			Scene.youWin();
		}
		else if(Game.zombieKill==true){
			Game.gameOver=true;
		}*/
	}

	public static double getTime(){
		return time;
	}
	public static int seconds(){
		return seconds++;
	}

	public static void setZombieKill(boolean zombieKill){
		zombieKill=true;
	}
	public static void setGameOver(boolean gameOver){
		if(zombieKill==true){
			Game.gameOver=true;
		} 
		else{
			Game.gameOver=true;
		}
		
	}

	public static void gameOver(){
		Scene.gameOver(); 		//draw scene
		StdDraw.show(100); 	//show graphics
	}
	public static void gameWin(){
		Scene.youWin(); 		//draw scene
		StdDraw.show(100); 	//show graphics
		
		
	}

	
	

}