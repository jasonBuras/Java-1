public class Hud{

	public static void draw(){
		
		if (Player.getStamina() >= 75){
			StdDraw.setPenColor(0, 255, 0); // https://introcs.cs.princeton.edu/java/15inout/colors.html
			StdDraw.text(50, 20, "Stamina: " + Player.getStamina() );
		}
		else if ((Player.getStamina() < 75) && (Player.getStamina() >= 50)){
			StdDraw.setPenColor(255, 255, 0);
			StdDraw.text(50, 20, "Stamina: " + Player.getStamina() );
		}
		else if (Player.getStamina() < 50){
			StdDraw.setPenColor(255, 0, 0);
			StdDraw.text(50, 20, "Stamina: " + Player.getStamina() );
		}
		if (Player.getHealth() >= 75){
			StdDraw.setPenColor(0, 255, 0);
			StdDraw.text(50, 40, "Health: " + Player.getHealth() );
		}
		else if ((Player.getHealth() < 75) && (Player.getHealth() >= 50)){
			StdDraw.setPenColor(255, 255, 0);
			StdDraw.text(50, 40, "Health: " + Player.getHealth() );
		}
		else if (Player.getHealth() < 50){
			StdDraw.setPenColor(255, 0, 0);
			StdDraw.text(50, 40, "Health: " + Player.getHealth() );
		}
		StdDraw.setPenColor(0, 255, 0);
		//Debug
		StdDraw.text(400, 20, "PlayerX: " + Player.getPlayerX() );
		StdDraw.text(400, 40, "PlayerY: " + Player.getPlayerY() );
		StdDraw.text(600, 20, "ZombieX: " + Zombie.getZombieX() );
		StdDraw.text(600, 40, "ZombieY: " + Zombie.getZombieY() );
		StdDraw.text(800, 20, "Distance: " + Zombie.getDist() );
		StdDraw.text(800, 40, "Moving: " + Player.getIsMoving() );

		/*StdDraw.text(60, 35, "X Velocity: " + Physics.getVelocityX());
		StdDraw.text(60, 50, "Y Velocity: " + Physics.getVelocityY());*/
	}
}