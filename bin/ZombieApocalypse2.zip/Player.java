/*The Player class will contain all data/methods that model the player.
To draw the player to the scene, we need 5 pieces of data:
name (with file path), the width, the height, and the location in the canvas.
At this stage, the Player class only need two behaviors to achieve the goal:
start: initialize all of the data for the player by settings its data variables
draw: draw the player''s image to the canvas
After adding the Player class, update the Game class' start() method to invoke Enemy's start() method to initialize
the enemy, and update Game class' render() method to invoke Enemy's draw() method.*/
import java.util.Scanner;
import java.awt.event.KeyEvent;



public class Player{
	//Player data
	private static String playerRight;
	private static String playerLeft;
	private static String playerUp;
	private static String playerDown;
	private static String sprite;
	private static int width;
	private static int height;
	private static double x;
	private static double y;
	private static int health;
	private static double playerSpeed = 3;
	private static double playerSprintSpeed = 6;
	private static int playerStamina=100;
	private static int maxStamina=100;
	private static double staminaSlider = 1; // bigger number means stamina drains faster
	private static int playerHealth = 100;
	private static long time; //1000ms = 1sec
	private static int noMagicNumbers;
	private static boolean isMoving=false;
	private static long staminaTimer;

	


	public static void draw () {
		StdDraw.picture(x+width/2 , y + height/2, sprite);
	}
	
	public static void start (Scanner input){
		playerRight = "assets/playerRight.png";
		playerLeft = "assets/playerLeft.png";
		playerUp = "assets/playerUp.png"; 
		playerDown = "assets/playerDown.png";
		width=50;
		height=50;
		x = 9;
		y = 39;
		
		sprite = playerRight;
		
	}
	public static void update(){
		Player.move();
		Player.staminaRegen();
		if (playerHealth <=0){
			Game.setZombieKill(true);
			Game.setGameOver(true);

		}
		if(Exit.isTouching()==true){
			Game.gameWin();
		}

	}
	/*public static void keyPressed(KeyEvent e){ //experimental
		if (e.getKeyCode() == KeyEvent.VK_W){
			moveUp = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_S){
			moveDown = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_D){
			moveRight = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_A){
			moveLeft = true;
		}
	}*/
	public static void move(){
		if(StdDraw.hasNextKeyTyped()){
			if (StdDraw.isKeyPressed('W') && (playerStamina > 0) && StdDraw.isKeyPressed(KeyEvent.VK_SHIFT) && (y > 0)){
				y = y - (playerSpeed * 2);
				sprite = playerUp;
				playerStamina -= staminaSlider;
				isMoving=true;
			}
			else if (StdDraw.isKeyPressed('S') && (playerStamina >= 0) && StdDraw.isKeyPressed(KeyEvent.VK_SHIFT) && (y < Scene.getHeight()-5)){
				y = y + (playerSpeed * 2);
				sprite = playerDown;
				playerStamina -= staminaSlider;
				isMoving=true;
			}
			else if(StdDraw.isKeyPressed('D') && (playerStamina >= 0) && StdDraw.isKeyPressed(KeyEvent.VK_SHIFT) && (x < Scene.getWidth())){
				x = x + (playerSpeed * 2);
				sprite = playerRight;
				playerStamina -= staminaSlider;
				isMoving=true;
			}
			else if(StdDraw.isKeyPressed('A') && (playerStamina >= 0) && StdDraw.isKeyPressed(KeyEvent.VK_SHIFT) && (x >= 0)){
				x = x - (playerSpeed * 2);
				sprite = playerLeft;
				playerStamina -= staminaSlider;
				isMoving=true;
			}
			else if (StdDraw.isKeyPressed('W') && (y > 0) && (playerStamina >= 0)){ // https://docs.oracle.com/javase/6/docs/api/java/awt/event/KeyEvent.html
				y = y - playerSpeed;
				sprite = playerUp;
				isMoving=true;
			}
			else if (StdDraw.isKeyPressed('S') && (y < Scene.getHeight()-5) && (playerStamina >= 0)){
				y = y + playerSpeed;
				sprite = playerDown;
				isMoving=true;
			}
			else if(StdDraw.isKeyPressed('D') && (x < Scene.getWidth())&& (playerStamina >= 0)){
				x = x + playerSpeed;
				sprite = playerRight;
				isMoving=true;
			}
			else if(StdDraw.isKeyPressed('A') && (x > 0)&& (playerStamina >= 0)){
				x = x - playerSpeed;
				sprite = playerLeft;
				isMoving=true;
			}
			/*else if ((StdDraw.isKeyPressed('W')) && (StdDraw.isKeyPressed('D')) && (y > 0)){ 
				y = y - playerSpeed/2;
				x = x + playerSpeed/2;
				sprite = playerUp;
			}
			else if ((StdDraw.isKeyPressed('W')) && (StdDraw.isKeyPressed('A')) && (y < Scene.getHeight()-5)){
				y = y - playerSpeed/2;
				x = x - playerSpeed/2;
				sprite = playerDown;
			}
			else if ((StdDraw.isKeyPressed('S')) && (StdDraw.isKeyPressed('D')) && (x < Scene.getWidth())){
				y = y + playerSpeed/2;
				x = x + playerSpeed/2; 
				sprite = playerRight;
			}
			else if ((StdDraw.isKeyPressed('S')) && (StdDraw.isKeyPressed('A')) && (x > 0)){
				y = y + playerSpeed/2;
				x = x - playerSpeed/2;
				sprite = playerLeft;
			}*/ //Diagonal Movement. First Test: Fail. Second Test: Revisited, awaiting testing.
			else{
				isMoving=false;
				staminaRegen();
			}
			
		}
	}

	public static double getPlayerX(){
		return x;
	}
	public static double getPlayerY(){
		return y;
	}
	public static int getStamina(){
		return playerStamina;
	}
	public static int getHealth(){
		return playerHealth;
	}
	public static void staminaRegen(){
	    long currentTime = System.currentTimeMillis();
	    if (isMoving){
	        staminaTimer = currentTime;
	    } 
	    if (currentTime - staminaTimer > 2500 ){
	       playerStamina += (playerStamina < maxStamina) ? 10 : maxStamina-playerStamina ; 
	       staminaTimer = currentTime;
	    }
	}
	public static void gotHit(){
		playerHealth = playerHealth - Zombie.getDamage();
		long startTime = System.currentTimeMillis(); //fetch starting time
		while(false||(System.currentTimeMillis()-startTime)<200){
    		playerSpeed=2;
		}
		Game.setZombieKill(true);
	}

	public static boolean getIsMoving(){
		return isMoving;
	}
	/*public static boolean noBueno(){
		boolean attacked;
		if(Zombie.getDist()<2){
			attacked=true;
		}
		else{
			attacked=false;
		}
		return attacked;
	}*/
}