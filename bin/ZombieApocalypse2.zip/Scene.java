//Contains all methods/data that manages the game scene or level
/*The Scene class will contain all data/methods that model the game scene.
In this game, the scene will appear as a static background image.
Therefore, the Scene class requires three pieces of data:
1. name (with filepath) of the image file (datatype: text)
2. width in pixels of the image file (datatype: int)
3. height in pixels of the image file (datatype: int)
At this stage, the Scene class only needs two behaviors:
start: initialize all of the data of the scene by settings its data variables
draw: draw the scene's image to the canvas

After adding the Scene class, update the Game class' start() method to invoke Scene's start() method to initially setup
a scene, and update Game class' render() method to invoke Scene's draw() method.
*/
import java.util.Scanner;
public class Scene{
	//Scene data --> accessible only within this class since labeled private.
	private static long time; //1000ms = 1sec
	private static String background; 
	private static String endScreen;
	private static String intro;// 7292 ms
	private static int width;
	private static int height;
	private static String youWin;


	
	public static void intro(){
		Scene.width= 960;
		Scene.height = 540;
		
		Scene.intro="assets/intro.gif";
		StdDraw.setCanvasSize(width, height); 
		StdDraw.setXscale(0.0, width);
		StdDraw.setYscale(height, 0.0);
		long startTime = System.currentTimeMillis(); //fetch starting time
		while(false||(System.currentTimeMillis()-startTime)<7292){
			
    		StdDraw.picture(width/2, height/2, intro);
		}
	}
	//Draws scene
	public static void draw(){
		StdDraw.picture(width/2, height/2, background);
	} 
	public static void start(){ 
		//Setup canvas data (size & scale)
		Scene.width= 960;
		Scene.height = 540;
		Scene.background= "assets/background.png";
		StdDraw.setCanvasSize(width, height); 
		StdDraw.setXscale(0.0, width);
		StdDraw.setYscale(height, 0.0);
	}

	public static int getWidth(){
		return width;
	}

	public static int getHeight(){
		return height;
	}

	
	public static void playIntro(){
		StdDraw.picture(width, height, intro);
		
	}
	public static void youWin(){
		Scene.width= 960;
		Scene.height = 540;
		
		Scene.youWin="assets/youwin.gif";
		StdDraw.setCanvasSize(width, height); 
		StdDraw.setXscale(0.0, width);
		StdDraw.setYscale(height, 0.0);
		long startTime = System.currentTimeMillis(); //fetch starting time
		while(false||(System.currentTimeMillis()-startTime)<5500){	
    		StdDraw.picture(width/2, height/2, youWin);
			StdDraw.show(100);
		}
		System.exit(0);

	}
	public static void gameOver(){
		Scene.width= 960;
		Scene.height = 540;
		Scene.endScreen ="assets/gameover.png";
		StdDraw.setCanvasSize(width, height); 
		StdDraw.setXscale(0.0, width);
		StdDraw.setYscale(height, 0.0);
		long startTime = System.currentTimeMillis(); //fetch starting time
		while(false||(System.currentTimeMillis()-startTime)<5000){
			StdDraw.picture(width/2, height/2, endScreen);
			StdDraw.show(100);
		}
		System.exit(0);		
	}
}