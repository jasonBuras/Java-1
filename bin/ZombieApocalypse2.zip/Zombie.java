public class Zombie{
	//zombie data --> accessible by all zombie methods, scoped for as long as Game class runs.
	private static String image;
	private static int width;
	private static int height;
	private static double x;
	private static double y;
	private static long time; //1000ms = 1sec
	private static double dist;
	private static double zombieSpeed=1;
	private static double randomSpeed = Math.random() * 3;
	private static int hitPower = 20;

	//draw zombie
	public static void draw(){
		StdDraw.picture(x+width/2,y+height/2, image);
	}

	public static void start(){
		image = "assets/zombie.png";
		width=50;
		height=50;
		//Look into better move methods
		x = Math.floor(Math.random() * (Scene.getWidth() - 300) + 300);
		y = Math.floor(Math.random() * (Scene.getHeight() - 300) + 300);
	}
	public static double distance(){
		 dist = Math.sqrt(Math.pow(x - Player.getPlayerX(),2)+Math.pow(y-Player.getPlayerY(),2));
			return Math.round(dist/zombieSpeed)*zombieSpeed;
	}

	public static void move(){ //Revisiting later
		if(distance() >= 250){
			int choice = (int) (Math.random()*4);
			if((choice==0) && (x < Scene.getWidth())){
				x= Math.floor(x + randomSpeed);
			}
			else if((choice==1) && (x > 0)){
				x= Math.floor(x- randomSpeed);
			} 
			else if((choice==2) && (y > 0)){
				y= Math.floor(y- randomSpeed);
			}
			else if((choice==3) && (y < Scene.getHeight())){
				y=Math.floor(y+ randomSpeed);
			}
			else{
				x = x ;
				y = y;
			}
		}
		/*
		TOMORROW: Implement distance to do the +1 movement if zombie is extremely close to the player, otherwise use zombieSpeed
		else if (distance() <= ___){
		}*/
		else if (distance() < 250){
			zombieSpeed = 2;
			if (x >= Player.getPlayerX()){
				x = x - zombieSpeed;
			}
			if (y < Player.getPlayerY()){
				y = y + zombieSpeed;
			}
			if (y >= Player.getPlayerY()){
				y = y - zombieSpeed;
			}
			if (x < Player.getPlayerX()){
				x = x + zombieSpeed;
			}
		}
		else if (distance() <= 20 && distance() > 2){
			zombieSpeed = 1.5;
			if (x > Player.getPlayerX()){
				x = x - zombieSpeed;
			}
			if (y < Player.getPlayerY()){
				y = y + zombieSpeed;
			}
			if (y >= Player.getPlayerY()){
				y = y - zombieSpeed;
			}
			if (x <= Player.getPlayerX()){
				x = x + zombieSpeed;
			}
		}
		/*else if (x >= Player.getPlayerX()){
			x = x - zombieSpeed;
		}
		else if (y < Player.getPlayerY()){
			y = y + zombieSpeed;
		}
		else if (y >= Player.getPlayerY()){
			y = y - zombieSpeed;
		}
		else if (x < Player.getPlayerX()){
			x = x + zombieSpeed;
		}
		else{
			x--;
			y++;
		}*/
		if (distance()<=2){
			zombieSpeed=1;
			Player.gotHit();
		}
	}

	public static void update(){
		/*long now = System.currentTimeMillis();
		if(now-time > 1000){*/
			move();
		//}
		
	}
	public static double getZombieX(){
		return x;
	}
	public static double getZombieY(){
		return y;
	}
	public static int getDamage(){
		return hitPower;
	}
	public static double getDist(){
		return dist;
	}
}