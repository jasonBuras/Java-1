/*[Jason Buras][Nov 2022][Discord: rambeaux504#3269]
 * Idea: A combination of both games in which a number is picked at random.
 * User selects heads or tails to decide who goes first between the player and computer.
 * The winner of the coin toss will pick a number within the given range. If they guess wrong,
 * the other play gets a chance to guess. Whichever player guesses the number first gets a point (or wins)*/
import java.util.Scanner;
import java.util.ArrayList;

//Toolkit.getDefaultToolkit().beep(); //produces default windows sound (dun dun dun)
public class RussianRoulette {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";
    public static final String ANSI_GREEN = "\u001B[31m";

    private static boolean gameOver;
    private static double randomNumber;
    private static boolean isCorrect;
    private static double range = 100;

    private static int playerScore;
    private static boolean playerTurn;

    private static boolean tooHigh;
    private static String highLow;
    private static int computerScore;
    private static boolean computerTurn;
    private static int targetScore = 3; //Best of 3: 2 | Best of 5: 3 | Best of 7: 4 | etc.


    private static boolean coinTossWin;
    private static double gameMasterDelay = 3.0; //sets delay for game master to "think"

    private static String playerName= Game.getPlayerName();
    private static double median;
    private static int logLength;

    public static void start(){
        gameOver=false;
        Scanner numberSelect = new Scanner(System.in);
        System.out.printf(ANSI_RED+ "[Russian Roulette]" +ANSI_RESET + "\nYou will pick a number between 1 and %.0f.\nThe computer will also pick a number in that range\nThis will be a race to see who can guess the number first\nThe answer MUST BE a WHOLE number (no decimals)\nPress [ENTER] to continue", range);
        String poo=numberSelect.nextLine();
        GameEngine.clear();

        //coinflip();
        GameEngine.expCoinflip();
        GameEngine.delay(3);
        GameEngine.clear();
        newRandomNumber();

        //Start game
        isFirstGuess=true;
        if(coinTossWin){
            while (!gameOver) {
                System.out.printf("Score:\n%s: %d/%d\nComputer: %d/%d\n", playerName, playerScore, targetScore, computerScore, targetScore);
                playerGuess();
                check();
                computerGuess();
                check();
            }
        }
        if(!coinTossWin) {
            while (!gameOver) {
                System.out.printf("Score:\n%s: %d/%d\nComputer: %d/%d\n",playerName, playerScore, targetScore, computerScore, targetScore);
                computerGuess();
                check();
                playerGuess();
                check();
            }
        }
    }

    public static void setRange(double range) {
        RussianRoulette.range = range;
    }

    private static int playerNumber;
    private static int lastGuess;
    private static void playerGuess(){
        playerTurn=true;
        computerTurn=false;
        Scanner playerInput = new Scanner(System.in);
        System.out.printf("Pick a number between 1-%.0f,\nor 0 to check previous guesses: ",range);
        playerNumber = playerInput.nextInt();
        //Out of bounds error handling
        while(playerNumber <= 0 || playerNumber > range){
            if (playerNumber < 0 || playerNumber > range) {
                GameEngine.clear();
                System.out.printf("Your number was out of range,\nplease select a number between (and including) 1 and %.0f\n",range);
                playerNumber = playerInput.nextInt();

            }
            else if (playerNumber==0){
                if(playerNumber==0) {//Utilize an array to produce a log of ALL previous guesses
                    GameEngine.clear();
                    printGuessLog();
                    System.out.printf("Pick a number between 1-%.0f: ", range);
                    playerNumber = playerInput.nextInt();
                }
            }
        }//end error handling

        lastGuess=playerNumber; logGuess();
    }
    public static double getRandomNumber(){
        return randomNumber;
    }
    private static boolean cpuTooHigh;
    private static double computerGuess;
    private static boolean isFirstGuess;
    private static double cpuDelay = 3.0;

    public static void computerGuess(){
        System.out.println("Computer is picking a number...");
        GameEngine.delay(cpuDelay);
        playerTurn=false;
        computerTurn=true;
        if(isFirstGuess && lastGuess==0){//For first guess, adjust the randomness to keep it around the midway point in the range for realism
            computerGuess = range/2;
        }else if(isFirstGuess && lastGuess>0){
            double temp = GameEngine.getRandom(1,2);
            if(temp==1){
                computerGuess =(range/2) +1;
            }else if(temp==2){
                computerGuess = (range/2) -1;
            }
        }
        else if(!isFirstGuess){
            if(cpuTooHigh){
                computerGuess = Math.round(computerGuess/2);
            }
            if(!cpuTooHigh){
                computerGuess=Math.round((computerGuess*.5)+computerGuess);
            }
            while(computerGuess == playerNumber && cpuTooHigh){
                computerGuess--;
            }while(computerGuess == playerNumber && !cpuTooHigh){
                computerGuess++;
            }

            /*else if (computerGuess >= randomNumber && computerGuess - randomNumber >= 5 && computerGuess - randomNumber < 10 ) {
                computerGuess = computerGuess - (Math.round(Math.random() * (9 -3))+3);
                while(computerGuess > range){computerGuess--;}
                while(computerGuess < 0){computerGuess++;}
            } else if (computerGuess <= randomNumber && computerGuess - randomNumber <= 5 && computerGuess - randomNumber > 10) {
                computerGuess = computerGuess + (Math.round(Math.random() * (9 -3))+3);
                while(computerGuess > range){computerGuess--;}
                while(computerGuess < 0){computerGuess++;}
            }  else if (computerGuess >= randomNumber && computerGuess - randomNumber >= 10) {
                computerGuess = computerGuess - (Math.round(Math.random() * (range -3))+3);
                while(computerGuess > range){computerGuess--;}
                while(computerGuess < 0){computerGuess++;}
            } else if (computerGuess <= randomNumber && computerGuess - randomNumber <= 10) {
                computerGuess = computerGuess + (Math.round(Math.random() * (range -3))+3);
                while(computerGuess > range){computerGuess--;}
                while(computerGuess < 0){computerGuess++;}
            }else if (computerGuess >= randomNumber && computerGuess - randomNumber >= 2 && computerGuess - randomNumber < 5) {
                computerGuess -= (Math.round(Math.random() * (3 -1))+1);
                while(computerGuess > range){computerGuess--;}
                while(computerGuess < 0){computerGuess++;}
            } else if (computerGuess <= randomNumber && computerGuess - randomNumber <= 2 && computerGuess - randomNumber > 5) {
                computerGuess += (Math.round(Math.random() * (3 -1))+1);
                while(computerGuess > range){computerGuess--;}
                while(computerGuess < 0){computerGuess++;}
            } else if (computerGuess >= randomNumber && computerGuess - randomNumber >= 1) {
                computerGuess--;
            } else if (computerGuess <= randomNumber && computerGuess - randomNumber <= 1) {
                computerGuess++;
            } else {
                System.out.println("[ELSE TRIGGERED] Please give me a heads up if you encounter this");
            }*/
        }

        if (computerGuess > randomNumber) {
            cpuTooHigh=true;
        }else if(computerGuess<randomNumber){
            cpuTooHigh=false;
        }while(computerGuess>range){computerGuess--;}while(computerGuess<1){computerGuess++;}
        isFirstGuess=false;
        lastCPUguess = computerGuess;
    }
    private static double lastCPUguess;
    public static void coinflip() {//Coin Flip
        Scanner headsTails = new Scanner(System.in);

        System.out.println("Select Head or Tails!\n1) Heads or\n2) Tails");
        int temp = headsTails.nextInt();
        while (temp < 1 || temp > 2) {
            GameEngine.clear();
            System.out.println("Your number was out of range, please select either\n[1] Heads or\n[2] Tails\n");
            temp = headsTails.nextInt();
        }
        GameEngine.clear();
        System.out.println("The coin is in the air...");
        double coinTossDelay = GameEngine.getRandom(2.0,3.0);
        GameEngine.delay(coinTossDelay);
        GameEngine.clear();
        double headsortails = GameEngine.getRandom(1,2);
        if (headsortails == 1 && headsortails == temp) {
            System.out.println("It was Heads");
            System.out.println("You win the coin toss and will play first!");
            coinTossWin = true;
        } else if (headsortails == 2 && headsortails == temp) {
            System.out.println("It was tails");
            System.out.println("You win the coin toss and will play first!");
            coinTossWin = true;
        }
        if (headsortails == 1 && headsortails != temp) {
            System.out.println("It was Heads");
            System.out.println("You lose the coin toss and the computer plays first!");
            coinTossWin = false;
        } else if (headsortails == 2 && headsortails != temp) {
            System.out.println("It was tails");
            System.out.println("You lose the coin toss and the computer plays first!");
            coinTossWin = false;
        }//end coin flip
        GameEngine.delay(3);
    }

    public static void setCoinTossWin(boolean coinTossWin) {
        RussianRoulette.coinTossWin = coinTossWin;
    }

    private static boolean roundOver;
    private static void check(){
        roundOver =false;
        if(playerNumber==randomNumber && playerTurn){
            GameEngine.clear();
            System.out.printf("%s Guessed: %d\nWhich was correct!\nYou win!\n",playerName, playerNumber);
            playerScore++;
            roundOver =true;
            logGuess();
            playerTurn=false;
            newRandomNumber();

            GameEngine.clear();
        } else if(playerNumber>randomNumber && playerTurn){
            GameEngine.clear();
            System.out.printf("%s Guessed: %d\nWhich was incorrect.\n"+ ANSI_RED + "TOO HIGH"+ ANSI_RESET + "\n" ,playerName, playerNumber);
            playerTurn=false;
        }else if(playerNumber<randomNumber && playerTurn){
            GameEngine.clear();
            System.out.printf("%s Guessed: %d\nWhich was incorrect.\n"+ ANSI_RED + "TOO LOW"+ ANSI_RESET + "\n" ,playerName, playerNumber);
            playerTurn=false;
        }

        if(computerGuess==randomNumber && computerTurn){
            GameEngine.clear();
            System.out.printf("Computer Guessed: %.0f\nWhich was "+ ANSI_GREEN + "CORRECT!"+ ANSI_RESET + "\nThe Computer wins!\n",computerGuess);
            computerScore++;
            roundOver =true;
            logGuess();
            computerTurn=false;
            newRandomNumber();
        }else if(computerGuess>randomNumber && computerTurn){
            GameEngine.clear();
            System.out.printf("Computer Guessed: %.0f, which was "+ ANSI_RED + "incorrect"+ ANSI_RESET + "\n" ,computerGuess);
            computerTurn=false;
        }else if(computerGuess<randomNumber && computerTurn){
            GameEngine.clear();
            System.out.printf("Computer Guessed: %.0f, which was "+ ANSI_RED + "incorrect"+ ANSI_RESET + "\n" ,computerGuess);
            computerTurn=false;
        }
        if(playerScore == targetScore){
            gameOver=true;
            playerScore=0;
            computerScore=0;
            Game.youWin();

        }
        if(computerScore == targetScore){
            gameOver=true;
            playerScore=0;
            computerScore=0;
            Game.youLose();
        }
        if(roundOver){
            isFirstGuess=true;
        }
    }
    private static ArrayList<String> guessLog = new ArrayList<>(); //ArrayList object
    public static void logGuess(){
        if(lastGuess > randomNumber){
            highLow = "high";
        }
        else if(lastGuess < randomNumber){
            highLow="low";
        }
        String temp = Integer.toString(lastGuess);
        String logger = temp + " which was " + highLow;
        guessLog.add(logger);

        if(roundOver || computerGuess==randomNumber || playerNumber == randomNumber){
            guessLog.clear();
        }

    }
    public static void printGuessLog(){
        System.out.println("Previous Guesses this round:");
        System.out.println("-----------------------------");
        for(String log : guessLog){//look into this
            if(guessLog.size()<=0) {
                System.out.println("You have not made any guesses this round");
                System.out.println("-----------------------------");
            }
            else{
                System.out.println(log);
                System.out.println("-----------------------------");
            }
        }
    }

    public static void newRandomNumber(){
        lastGuess=0;
        playerNumber=0;
        computerGuess=0;
        System.out.printf("Game Master is picking a number in between (and including) 1-%.0f...\n", range);
        randomNumber = ((Math.round(Math.random() * (range -1))+1));
        GameEngine.delay(gameMasterDelay);
        GameEngine.clear();
        System.out.printf("Game Master has picked a number.\nBest of luck!\n", range);
    }

    public static int getTargetScore() {
        return targetScore;
    }

    public static void setTargetScore(int targetScore) {
        RussianRoulette.targetScore = targetScore;
    }

    public static void setGameMasterDelay(double gameMasterDelay) {
        RussianRoulette.gameMasterDelay = gameMasterDelay;
    }

    public static void setCpuDelay(double cpuDelay) {
        RussianRoulette.cpuDelay = cpuDelay;
    }
}
