Game.java is your main

Disclaimer: Have done limited testing since Refactoring NumberGame.java to Game.java
I believe all the references to NumberGame.java have been translated to Game.java.


[Russian Roulette]
I think it's stable now. Through 5 rounds of testing, Computer made logical guesses. Very excited.

Okay.. so further testing shows Computer logic needs more work. Store its guesses in an array to avoid repeats.

QOL Plans:
(FINISHED) Use an array to print out the log of previous guesses and clear it once the round is over

Bugs:
The computer will repeat guesses. (ie, when guessing 100, it will guess 50 based on the algorithm.

Plans to fix:
Look closer at the computer guessing algorithm. Brainstorm a way for the computer to check if its next guess will be too high/too low
based on previous boolean (cpuTooHigh) values.

[Optimization]
-Moved Delay, RandomNumber(), etc out of the game code and into GameEngine.java

[Stability]
-Stable enough to show off to friends/peers/family.
-Develop thick skin for when they see the faulty algorithm.

[Bug Fixes]
-a lot.. lost track