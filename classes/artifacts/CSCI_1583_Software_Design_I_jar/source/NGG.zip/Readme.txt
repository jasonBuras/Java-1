[How to run]
You will need Java Runtime Environment(JRE) on your computer.
https://www.java.com/en/

Automatic:
Double click run.bat (Not sure what this does on MacOS/Linux yet. Will test on Linux tomorrow)

This works much better in a terminal instead of cmd.exe (If you're on Windows atleast)

Manual:	
	I honestly don't know if Windows even comes with a terminal built in. If not you have options.
	If I'm not mistaken, MacOS comes with a built in terminal. And I know for sure linux does.
	
	Windows step your game up... This should come natively:
		(Microsoft)[Windows Terminal]: https://apps.microsoft.com/store/detail/windows-terminal/9N0DX20HK701?hl=en-us&gl=us
	
	You should be able to right click inside the directory your .jar file is located and select "Open in Terminal"
		Note: 	If you do not see this option, simply use your terminal and type "dir" to see where you're at in the directory.
				Then use "cd [FolderName]" until you reach your destination (Hint: Use [TAB] to autofill directory names)
				Once you reach the folder simply copy/paste:       ( Copy= [Ctrl]+[Insert] | Paste= [Shift]+[Insert] ) 
				"java -jar NumberGuessingGame.jar" and press Enter. 
				The program should start.

[11/18/2022]
[Russian Roulette]
-implemented..
I'll type the rest later

[11/17/2022]
Cleaned up a lot of bugs/issues. Laid ground work for Russian Roulette mode.
[Russian Roulette]
-Idea: A combination of both games in which a number is picked at random.
-User selects heads or tails to decide who goes first between the player and computer.
-The winner of the coin toss will pick a number within the given range. 
-If they guess wrong,the other play gets a chance to guess. 
-Whichever player guesses the number first gets a point (or wins)
-Point system would lead to more options such as [Best of: 3, 5, 7, etc)]

[User input now needs to stay in range]
-If user input is out of range, an error message appears "reminding" them what the range is
-If the user is having trouble picking a number in the range, the terminal prints out ALL numbers in range

[Optimization]
-Removed NumberGuesser.postGameScreen(); from NormalGame/ComputerGuesses.youWin/Lose() methods. 
-.postGameScreen() is only called upon in the main method now for better optimization.

[Stability]
-Stable enough to show off to friends/peers/family.

[Bug Fixes]
-yep
		